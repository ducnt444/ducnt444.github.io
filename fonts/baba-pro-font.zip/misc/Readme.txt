Thank you for purchasing
https://graphicriver.net/item/babapro-font/25381818
++++++++++++++++++++++++++++++++++++++++++

Here simple guide you may like to know.

- just open the file and double click on it
- click install
- done