# DatPayment
demo : https://inem0o.github.io/DatPayment/

simple code example : https://github.com/iNem0o/DatPayment/blob/master/examples/simple.html


### Bower dependencies
- https://github.com/jessepollak/card
