import maskTrigger from './maskTrigger'
import preventEventsTrigger from './preventEventsTrigger'
import creditCardFlagTrigger from './creditCardFlagTrigger'

maskTrigger()
preventEventsTrigger()
creditCardFlagTrigger()
